package com.example.FileUploadSpringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FileUploadSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
